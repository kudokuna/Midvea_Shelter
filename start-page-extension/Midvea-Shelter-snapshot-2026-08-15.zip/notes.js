// notes.js — Notes Widget
document.addEventListener('DOMContentLoaded', () => {
    let notes = [];

    function loadNotes() {
        chrome.storage.local.get(['notes'], (r) => {
            notes = r.notes || [];
            renderNotes();
        });
    }

    function saveNotes() {
        chrome.storage.local.set({ notes: notes.map(n => ({ id: n.id, text: n.text })) });
    }

    function renderNotes() {
        const list = document.getElementById('notes-list');
        list.innerHTML = '';

        notes.forEach((note, idx) => {
            const noteEl = document.createElement('div');
            noteEl.className = 'notes-widget__note-widget';

            const content = document.createElement('div');
            content.className = 'notes-widget__content';
            content.contentEditable = 'true';
            content.textContent = note.text;
            content.spellcheck = false;

            content.addEventListener('blur', () => {
                notes[idx].text = content.textContent.trim();
                saveNotes();
            });

            content.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    content.blur();
                }
                if (e.key === 'Escape') content.blur();
            });

            const removeBtn = document.createElement('button');
            removeBtn.className = 'notes-widget__remove';
            removeBtn.innerHTML = '✕';
            removeBtn.title = 'Удалить';
            removeBtn.addEventListener('click', () => {
                notes.splice(idx, 1);
                saveNotes();
                renderNotes();
            });

            noteEl.appendChild(content);
            noteEl.appendChild(removeBtn);
            list.appendChild(noteEl);
        });

        // Add note inline button
        const addBtn = document.createElement('button');
        addBtn.className = 'notes-widget__add-note';
        addBtn.innerHTML = '<span style="font-size:15px;line-height:1">+</span> Новая заметка';
        addBtn.addEventListener('click', () => addNote());
        list.appendChild(addBtn);
    }

    function addNote() {
        const newNote = { id: Date.now(), text: '' };
        notes.push(newNote);
        saveNotes();
        renderNotes();
        // Focus last note
        setTimeout(() => {
            const contents = document.querySelectorAll('.notes-widget__content');
            if (contents.length > 0) contents[contents.length - 1].focus();
        }, 40);
    }

    // Header add button
    const headerAddBtn = document.getElementById('add-note-btn');
    if (headerAddBtn) {
        headerAddBtn.addEventListener('click', () => addNote());
    }

    loadNotes();
});
