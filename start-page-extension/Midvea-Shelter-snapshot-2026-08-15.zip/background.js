chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fetchImageSearch' || request.action === 'fetchDuckDuckGoImages') {
        searchImages(request.query)
            .then(result => sendResponse({ success: true, ...result }))
            .catch(err => sendResponse({ success: false, error: err.message }));

        return true; // Keep message channel open for async response
    }
});

async function searchImages(rawQuery) {
    const query = String(rawQuery || '').trim().slice(0, 200);
    if (!query) throw new Error('Пустой поисковый запрос');

    try {
        const images = await fetchDuckDuckGoImages(query);
        if (images.length > 0) return { images, source: 'duckduckgo' };
    } catch (error) {
        console.warn('DuckDuckGo image search failed, using fallback:', error.message);
    }

    const images = await fetchBingImages(query);
    if (images.length === 0) throw new Error('Изображения не найдены');
    return { images, source: 'bing' };
}

async function fetchDuckDuckGoImages(query) {
    const searchPage = await fetch(`https://duckduckgo.com/?q=${encodeURIComponent(query)}`, {
        headers: { 'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8' }
    });
    if (!searchPage.ok) throw new Error(`DuckDuckGo: HTTP ${searchPage.status}`);

    const html = await searchPage.text();
    const tokenMatch = html.match(/vqd=["']?([\d-]+)/) || html.match(/vqd%3D([\d-]+)/);
    if (!tokenMatch) throw new Error('DuckDuckGo не вернул токен поиска');

    const params = new URLSearchParams({
        l: 'ru-ru',
        o: 'json',
        q: query,
        vqd: tokenMatch[1],
        f: ',,,',
        p: '1'
    });
    const imageResponse = await fetch(`https://duckduckgo.com/i.js?${params}`, {
        headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        referrer: 'https://duckduckgo.com/',
        referrerPolicy: 'strict-origin-when-cross-origin'
    });
    if (!imageResponse.ok) throw new Error(`DuckDuckGo Images: HTTP ${imageResponse.status}`);

    const data = await imageResponse.json();
    return uniqueHttpUrls((data.results || [])
        .map(item => item.thumbnail || item.image)
    );
}

async function fetchBingImages(query) {
    const response = await fetch(`https://www.bing.com/images/search?q=${encodeURIComponent(query)}&form=HDRSC2`, {
        headers: { 'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8' }
    });
    if (!response.ok) throw new Error(`Bing Images: HTTP ${response.status}`);

    const html = await response.text();
    const images = [];
    const patterns = [
        /murl&quot;:&quot;(.*?)&quot;/g,
        /"murl"\s*:\s*"(https?:\\?\/\\?\/.*?)"/g
    ];
    patterns.forEach(pattern => {
        let match;
        while ((match = pattern.exec(html)) !== null) images.push(decodeSearchUrl(match[1]));
    });
    return uniqueHttpUrls(images);
}

function decodeSearchUrl(value) {
    return String(value || '')
        .replace(/\\u002f/gi, '/')
        .replace(/\\\//g, '/')
        .replace(/&amp;/g, '&')
        .replace(/&#39;/g, "'")
        .replace(/&quot;/g, '"');
}

function uniqueHttpUrls(values) {
    return [...new Set(values
        .filter(value => typeof value === 'string')
        .map(value => value.trim())
        .filter(value => /^https?:\/\//i.test(value))
    )].slice(0, 60);
}
